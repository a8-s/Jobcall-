import React from 'react'
import {Hero} from './HeroStyle'
import data from '../../data.js';

//import DataFetch from '../../data2.js';



interface Props {
    
}

export const HeroComp = (props: Props) => {
    return (
        <Hero id="hero">
        <h1>Hi, I'm {data.aboutParaOne}</h1>
        <h2 >I am looking for work. </h2>
        <a href="#about" className="btn-get-started scrollto">
            <i className="bi bi-chevron-double-down"></i></a>
        </Hero>
    )
}

