import React from 'react'
import data from '../data.js';

interface Props {
    
}

export const Resume = (props: Props) => {
    return (
    <section id="resume" className="resume section-bg">
      <div className="container">

        <div className="section-title">
          <h2>Resume</h2>
          <p>A full job history and various skills I have developed.</p>
        </div>

        <div className="row">
          <div className="col-lg-6">
            <h3 className="resume-title">Sumary</h3>
            <div className="resume-item pb-0">
              <h4>{data.aboutParaOne}</h4>
              <p><em>{data.aboutParaFour}</em></p>
              <p>
              <ul>
                <li>{data.aboutParaFive}</li>
                <li>{data.aboutParaSix}</li>
              </ul>
              </p>
            </div>

            <h3 className="resume-title">Education</h3>
            <div className="resume-item">
              <h4>{data.aboutParaFour} </h4>
              <h5>Time Frame</h5>
              <p><em> {data.aboutParaFour}</em></p>
              <p>{data.aboutParaFour}</p>
            </div>
            <div className="resume-item">
              <h4>{data.aboutParaFour}</h4>
              <h5>Time Frame</h5>
              <p><em>{data.aboutParaFour}</em></p>
              <p>{data.aboutParaFour}</p>
            </div>
          </div>
          <div className="col-lg-6">
            <h3 className="resume-title">Example Experience</h3>
            <div className="resume-item">
              <h4>Cook.</h4>
              <h5>Time Frame</h5>
              <p><em>{data.aboutParaFour} </em></p>
              <p>
              <ul>
                <li>Experience.</li>
                
                
                
              </ul>
              </p>
            </div>
            <div className="resume-item">
              <h4>Cook</h4>
              <h5>Time Frame</h5>
              <p><em>{data.aboutParaFive}</em></p>
              <p>
              <ul>
                <li>Expereince</li>
              </ul>
              </p>
            </div>
          </div>
        </div>

      </div>
    </section>
    )
}
