import React from 'react'
import data from '../data.js';

interface Props {
    
}

export const About = (props: Props) => {
    return (
    <section id="about" className="about">
      <div className="container">

        <div className="row no-gutters">
          <div className="image col-xl-4 d-flex align-items-stretch justify-content-center justify-content-lg-start"></div>
          
          <div className=" col-xl-8 ps-0 ps-lg-5 pe-lg-1 d-flex align-items-stretch">
           
            <div className="content d-flex flex-column justify-content-center">
              <div className="box">
              <h3>I am a skilled {data.aboutParaThree}. </h3>
              <p>
                I can help with {data.aboutParaTwo}. Here is more information about me: 
              </p> 
              </div>
            </div>
          </div>
        </div>

      </div>
    </section>
    )
}

