import React from 'react'

import SwiperCore, { Navigation, Pagination, A11y } from 'swiper';

import { Swiper, SwiperSlide } from 'swiper/react';
import data from '../data.js';
// Import Swiper styles
import 'swiper/swiper.scss';
import 'swiper/components/navigation/navigation.scss';
import 'swiper/components/pagination/pagination.scss';
import 'swiper/components/scrollbar/scrollbar.scss';
import useWindowDimensions from '../util/windowDimens';

// install Swiper modules
SwiperCore.use([Navigation, Pagination, A11y]);

interface Props {
    
}

export const Testimonial = (props: Props) => {        
        const {width,} = useWindowDimensions()
        const val = width<760?1:3
    return (
        
    <section id="testimonial" className="testimonials section-bg">
    <div className="container">
        
    <div className="swiper-wraper">

        <Swiper
            autoplay = {{
                delay: 5000
            }}
          spaceBetween={50}
          slidesPerView={val}
          pagination={{ clickable: true }}
          onSwiper={(swiper) => console.log(swiper)}
          onSlideChange={() => console.log('slide change')}
        >
          <SwiperSlide> <div className="swiper-slide">
              <div className="testimonial-item">
                <p>
                  <i className="bx bxs-quote-alt-left quote-icon-left"></i>
                  Testimonial coming soon 
                  <i className="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                
                <h3>{data.aboutParaOne}</h3>
                <h4>{data.aboutParaThree}</h4>
              </div>
            </div></SwiperSlide>
          <SwiperSlide><div className="swiper-slide">
              <div className="testimonial-item">
                <p>
                  <i className="bx bxs-quote-alt-left quote-icon-left"></i>
                  Testimonial coming soon 
                  <i className="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                
                <h3>{data.aboutParaOne}</h3>
                <h4>{data.aboutParaThree}</h4>
              </div>
            </div></SwiperSlide>
          <SwiperSlide><div className="swiper-slide">
              <div className="testimonial-item">
                <p>
                  <i className="bx bxs-quote-alt-left quote-icon-left"></i>
                  Testimonial coming soon 
                  <i className="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
               
                <h3>{data.aboutParaOne}</h3>
                <h4>{data.aboutParaThree}</h4>
              </div>
            </div></SwiperSlide>
          <SwiperSlide><div className="swiper-slide">
              <div className="testimonial-item">
                <p>
                  <i className="bx bxs-quote-alt-left quote-icon-left"></i>
                  Export tempor illum tamen malis malis eram quae irure esse labore quem cillum quid cillum eram malis quorum velit fore eram velit sunt aliqua noster fugiat irure amet legam anim culpa.
                  <i className="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
                
                <h3>Mara Andrews</h3>
                <h4>Designer</h4>
              </div>
            </div></SwiperSlide>
        </Swiper>
        </div>
    </div>
    </section>
      );
}

