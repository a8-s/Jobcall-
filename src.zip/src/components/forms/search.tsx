import React from 'react'

interface Props {
    
}

export const Search = (props: Props) => {
    return (
        <div>
            
        </div>
    )
}
